<?php 
if(!isset($_SESSION["id"]) && isset($_COOKIE["user_id"])) {
    $_SESSION["id"] = $_COOKIE["user_id"];

    $sql = mysqli_query($conn, "SELECT id,email,contact, password, status,isAdmin FROM users WHERE id = '".$_SESSION["id"]."'");
    $row = mysqli_fetch_assoc($sql);

    if($row['isAdmin'] == '2') {
        $acptgrpqury = mysqli_query($conn, "SELECT id FROM grpwise WHERE link='".$prts."' and status=1");
        $acptgrprslt = mysqli_fetch_array($acptgrpqury, MYSQLI_ASSOC);

             
        if(!empty($acptgrprslt['id'])) {
        
            header('Location: ' . $_SERVER['REQUEST_URI']);
            echo '<script>location.reload();</script>';
            exit();
        } else {
            $encoded_encrypted_number = "";
            if(SECRET_KEY) {
                $iv = openssl_random_pseudo_bytes(16);
                $encrypted_number = openssl_encrypt($row['id'], 'aes-256-cbc', SECRET_KEY, 0, $iv);
                $encoded_encrypted_number = urlencode(base64_encode($encrypted_number));
            }

            if(isset($_GET["modal"]) && isset($_GET["redirect"])) {
                header('Location: ' . urldecode($_GET["redirect"]) . "?data=" . $encoded_encrypted_number . "&iv=" . urlencode($iv));
            }
            else {
                header('Location: ' . $baseurl . 'dashboard');
            }
        }
    } elseif($row['isAdmin'] == '3') {
        header( 'Location: ' . $baseurl . 'teacher/group' );
    } elseif($row['isAdmin'] == '1') {
        header( 'Location: ' . $baseurl . 'controlgear' );
    }


    
    exit;
}


if(isset($_GET["modal"]) && isset($_GET["redirect"]) && $_GET["modal"] == "login") { ?>
    <script type="text/javascript">
    $(document).ready(function(){$("#loginModal").modal("show");});
    </script>
<?php 
        if(!empty($_SESSION['id']) || !empty($_COOKIE['user_id'])) {
            $encoded_encrypted_number = "";
            $user_id = $_SESSION['id'] ?? $_COOKIE['user_id'];
            if(SECRET_KEY) {
                $iv = openssl_random_pseudo_bytes(16);
                $encrypted_number = openssl_encrypt($user_id, 'aes-256-cbc', SECRET_KEY, 0, $iv);
                $encoded_encrypted_number = urlencode(base64_encode($encrypted_number));
            }

            if(isset($_GET["redirect"])) {
                header('Location: ' . urldecode($_GET["redirect"]) . "?data=" . $encoded_encrypted_number . "&iv=" . urlencode($iv));
            }
        }
} 

if(!isset($_GET["modal"]) && isset($_GET["redirect"])) {
    if(!empty($_SESSION['id']) || !empty($_COOKIE['user_id'])) {
        $encoded_encrypted_number = "";
        $user_id = $_SESSION['id'] ?? $_COOKIE['user_id'];
        if(SECRET_KEY) {
            $iv = openssl_random_pseudo_bytes(16);
            $encrypted_number = openssl_encrypt($user_id, 'aes-256-cbc', SECRET_KEY, 0, $iv);
            $encoded_encrypted_number = urlencode(base64_encode($encrypted_number));
        }

        if(isset($_GET["redirect"])) {
            header('Location: ' . urldecode($_GET["redirect"]) . "?data=" . $encoded_encrypted_number . "&iv=" . urlencode($iv));
        }
    }
    else {
        header('Location: ' . urldecode($_GET["redirect"]) . "?data=0");
    }
}


if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['tp_pass'];

    $sql = mysqli_query($conn, "SELECT id,email,contact, password, status,isAdmin FROM users WHERE email = '".$email."'");
    $row = mysqli_fetch_assoc($sql);

    if ($email != $row['email'] ) {
        $errMsg = '<div class="alert-danger p-2 mb-2" role="alert">User <b>' . $email . '</b> not found.</div>';
    } elseif ( $email != $row[ 'email' ] && md5( $password ) != $row[ 'password' ] ) {
        $errMsg = '<div class="alert-danger p-2 mb-2" role="alert">Incorrect Email/Phone or Password.</div>';            
    } elseif ( $email == "" && $password == "" || $email == "" || $password == "" ) {
        $errMsg = '<div class="alert-danger p-2 mb-2" role="alert">Please Enter Email or Password.</div>';
    } elseif ( $row['status'] == 1 ) {
        if ( $row['password'] == md5( $password ) ) {
            $_SESSION[ 'id' ] = $row['id'];
            session_start();
            $_SESSION[ 'id' ];

            $cookie_name = "user_id";
            $cookie_value = $row['id'];
            $expiration_time = time() + 60 * 60 * 24 * 30; // 30 days (in seconds)

            setcookie($cookie_name, $cookie_value, $expiration_time, "/");

           // mysqli_close( $conn );
            session_write_close();
            
            if($row['isAdmin'] == '2') {
                $acptgrpqury = mysqli_query($conn, "SELECT id FROM grpwise WHERE link='".$prts."' and status=1");
                $acptgrprslt = mysqli_fetch_array($acptgrpqury, MYSQLI_ASSOC);

                     
                if(!empty($acptgrprslt['id'])) {
                
                    header('Location: ' . $_SERVER['REQUEST_URI']);
                    echo '<script>location.reload();</script>';
                    exit();
                } else {
                    $encoded_encrypted_number = "";
                    if(SECRET_KEY) {
                        $iv = openssl_random_pseudo_bytes(16);
                        $encrypted_number = openssl_encrypt($row['id'], 'aes-256-cbc', SECRET_KEY, 0, $iv);
                        $encoded_encrypted_number = urlencode(base64_encode($encrypted_number));
                    }

                    if(isset($_GET["modal"]) && isset($_GET["redirect"])) {
                        header('Location: ' . urldecode($_GET["redirect"]) . "?data=" . $encoded_encrypted_number . "&iv=" . urlencode($iv));
                    }
                    else {
                        header('Location: ' . $baseurl . 'dashboard');
                    }
                }
            } elseif($row['isAdmin'] == '3') {
                header( 'Location: ' . $baseurl . 'teacher/group' );
            } elseif($row['isAdmin'] == '1') {
                header( 'Location: ' . $baseurl . 'controlgear' );
            }
     

            
            exit;
        } else {
            $errMsg = '<div class="alert-danger p-2 mb-2" role="alert">Incorrect email or password</div>';
        }
    } else {
        $errMsg = '<div class="alert-danger p-2 mb-2" role="alert">Your account not Active</div>';
    }

    if(!empty($errMsg)) { ?>
        <script type="text/javascript">
        $(document).ready(function(){$("#loginModal").modal("show");});
        </script>
   <?php 
   } 
}

if (isset($_POST['register'])) {
    $user = $_POST['utype'];
	$name = $_POST['fullname'];
	$email = $_POST['email'];
	$contact = $_POST['mobile'];
	$pass = $_POST['password'];
    $cls = $_POST['clsName'];
    $school = $_POST['school'];
    $others = $_POST['others'];
    $genrateotp = generateNumericOTP(6);

$emailsql = mysqli_query($conn, "SELECT email FROM users WHERE email='".$email."'");
$emailrow = mysqli_fetch_assoc($emailsql);

if($user == '1') {
if(empty($school) && empty($cls)) {
    $errMsg2 = '<div class="alert-danger w-100 p-2 mb-2">All fields required.</div>';
}
} elseif($user == '2') {
    if(empty($school)) {
    $errMsg2 = '<div class="alert-danger w-100 p-2 mb-2">All fields required.</div>';
    }
} 

if($emailrow['email'] == $email) {
	$errMsg2 = '<div class="alert-danger w-100 p-2 mb-2">Email already registered.</div>';
} else {


    if($school == 'others') {
        $schoolN = '0';
    } else {
        $schoolN = $school;
    }

    $isAdmin = $user+1;

	mysqli_query( $conn, "INSERT INTO users(fullname,email,contact,password,confirmation_code,status,isAdmin,school,type,class,created_at,updated_at) VALUES ('".$name."','".$email."','".$contact."','".md5($pass)."','".md5($genrateotp)."','1','".$isAdmin."','".$schoolN."','".$user."','".$cls."',NOW(),NOW())" );
	
    $usersql = mysqli_query($conn, "SELECT id,isAdmin FROM users WHERE id='".$conn->insert_id."'");
    $userrow = mysqli_fetch_array($usersql, MYSQLI_ASSOC);

    $usercntsql = mysqli_query($conn, "SELECT COUNT(type) as user_count FROM users WHERE type='".$user."'");
    $usercntrow = mysqli_fetch_array($usercntsql, MYSQLI_ASSOC);

    if($school == 'others') {
        mysqli_query( $conn, "INSERT INTO school_management(name,status,userid,created_at,updated_at) VALUES ('".$others."',1,'".$userrow['id']."',NOW(),NOW())" );
        
        $schsql = mysqli_query($conn, "select id from school_management order by id desc");
        $schrow = mysqli_fetch_array($schsql, MYSQLI_ASSOC);

        mysqli_query( $conn, "update users Set school='".$schrow['id']."',updated_at=NOW() WHERE id=".$userrow['id']."" );
    }
    
    if($user == '1') {
        $user = 'STU00'.$usercntrow['user_count'];
    } elseif($user == '2') {
        $user = 'TEC00'.$usercntrow['user_count'];
    }
    
    mysqli_query( $conn, "update users Set userid='".$user."',updated_at=NOW() WHERE id=".$userrow['id']."" );

    $_SESSION[ 'id' ] = $userrow['id'];
    session_start();
    $_SESSION[ 'id' ];
    
    mysqli_close( $conn );
    session_write_close();    	
	
    if($userrow['isAdmin'] == '2') {
        // header('Location: ' . $baseurl . 'dashboard');
        $encoded_encrypted_number = "";
        if(SECRET_KEY) {
            $iv = openssl_random_pseudo_bytes(16);
            $encrypted_number = openssl_encrypt($userrow['id'], 'aes-256-cbc', SECRET_KEY, 0, $iv);
            $encoded_encrypted_number = urlencode(base64_encode($encrypted_number));
        }

        if(isset($_GET["modal"]) && isset($_GET["redirect"])) {
            header('Location: ' . urldecode($_GET["redirect"]) . "?data=" . $encoded_encrypted_number . "&iv=" . urlencode($iv));
        }
        else {
            header('Location: ' . $baseurl . 'dashboard');
        }
    } elseif($userrow['isAdmin'] == '3') {
       header( 'Location: teacher/group' );
    }	
}
if(!empty($errMsg2)) { ?>
    <script type="text/javascript">
    $(document).ready(function(){
        $("#registerModal").modal("show");
    });
    </script>
<?php }
}

if(isset($_POST["contact"])) {
    $user_id = $_SESSION["id"];
    $subject = $_POST["subject-select"];
    $query_content = $_POST["query-content"];

    $sql = mysqli_query($conn, "INSERT INTO user_queries (user_id, subject, query_content, created_at, updated_at) VALUES ('$user_id', '$subject', '$query_content', NOW(), NOW())");
    if($row = mysqli_fetch_assoc($sql)){

    }
}
?>
</main>
    <footer>
        <div class="footer pb-4 <?php if($page != 'index.php' && $page != 'dashboard.php' && $page != 'category.php') { echo "mt-4";} ?>">
            <div class="container <?php if($page != 'dashboard.php' && $page != 'category.php' && $page != 'practice.php' && $page != 'quiz.php' && $page != 'fastest.php' && $page != 'shortlist.php') { echo "bt-1";} ?>">
                <div class="row justify-content-center pt-4">
                    <?php if($page != 'dashboard.php' && $page != 'practice.php' && $page != 'paper.php' && $page != 'quiz.php' && $page != 'fastest.php' && $page != 'leaderboard.php' && $page != 'category.php' && $page != 'shortlist.php') { ?>
                        <div class="col-lg-5 col-12 pe-lg-5 mt-lg-4 pb-3">
                        <img class="mb-3" src="<?php echo $baseurl; ?>assets/images/wonderkids-logo.svg" width="200" height="22" alt="">
                        <p>We thrive to create values for kids, parents and teachers. Please feel free to write us/reach out to us if you have any queries/feedback/concerns/suggestions. </p>
                        <div class="social">
                            <a href="#" class="link" target="_blank"
                                title="LinkedIn"><img src="<?php echo $baseurl; ?>assets/images/linkedin-ico.svg" width="18" height="18" alt=""></a>
                            <a href="#" class="link"
                                target="_blank" title="Instagram"><img src="<?php echo $baseurl; ?>assets/images/instagram-ico.svg" width="18" height="18" alt=""></a>
                            <a href="#" class="link" target="_blank"
                                title="Facebook"><img src="<?php echo $baseurl; ?>assets/images/facebook-ico.svg" width="18" height="18" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 mt-md-4 mt-5">
                        <div class="footer-widget">
                            <h3 class="heading text-uppercase mb-3">Browse by Class</h3>
                            <ul class="list">
                            <?php 
                $sclwiseSQL = mysqli_query($conn, "SELECT id,name,slug FROM subject_class WHERE type=2 and status=1 order by id asc");
                while($sclwiseRow = mysqli_fetch_assoc($sclwiseSQL)) { ?>
                    <li>
                    <?php 
                    $topicsql = mysqli_query($conn, "SELECT DISTINCT subject_id FROM topics_subtopics WHERE class_id=".$sclwiseRow['id']." and parent=0 and status=1");
                    while($topicrow = mysqli_fetch_assoc($topicsql)) {

                    $subjectsql = mysqli_query($conn, "SELECT name,slug FROM subject_class WHERE id=".$topicrow['subject_id']." and status=1");
                    $subjectrow = mysqli_fetch_assoc($subjectsql);    

                    $topiCntsql = mysqli_query($conn, "SELECT COUNT(subtopic) as count FROM topics_subtopics WHERE class_id=".$sclwiseRow['id']." and subject_id=".$topicrow['subject_id']." and parent!=0 and status=1");
                    $topiCntrow = mysqli_fetch_assoc($topiCntsql); ?>
                                
                                <?php if(empty($_SESSION['id'])) { ?>
                        <a href="#login" data-bs-toggle="modal" data-bs-target="#loginModal">
                        <?php } else { ?>
                        <a href="<?php echo $subjectrow['slug'].'/'.$sclwiseRow['slug']; ?>">
                        <?php } ?><?php echo $sclwiseRow['name']; ?></a></li>
                        <?php } } ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 mt-md-4 mt-5">
                        <div class="footer-widget">
                            <h3 class="heading text-uppercase mb-3">Resources</h3>
                            <ul class="list">
                                <li><a href="<?php echo $baseurl; ?>">Home</a></li>
                                <li><a href="#">About us</a></li>
                                <li><a href="#" data-bs-toggle="modal" data-bs-target="#contactModal">Contact us</a></li>
                                <li><a href="<?php echo $baseurl; ?>privacy-policy">Privacy Policy</a></li>
                                <li><a href="<?php echo $baseurl; ?>terms-and-conditions">Terms & Conditions</a></li>
                                <li><a href="<?php echo $baseurl; ?>disclaimer">Disclaimer</a></li>
                                <li><a href="<?php echo $baseurl; ?>copyright">Copyright</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 mt-md-4 mt-5 mb-4">
                        <div class="footer-widget">
                            <h3 class="heading text-uppercase mb-3">Contact Information</h3>
                            <ul class="list list-flex">
                                <li><span class="ico"><img src="<?php echo $baseurl; ?>assets/images/mail.svg" width="20" height="20" alt=""></span><a href="#" data-bs-toggle="modal" data-bs-target="#contactModal"
                                        class="link">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <?php } ?>
                    <?php if($page != 'practice.php' && $page != 'fastest.php' && $page != 'quiz.php' && $page != 'shortlist.php') { ?>
                    <?php if($page != 'dashboard.php' && $page != 'practice.php' && $page != 'paper.php' && $page != 'quiz.php' && $page != 'fastest.php' && $page != 'leaderboard.php' && $page != 'category.php') { ?>
                        <div class="col-md-12 mt-lg-5 mt-3">
                    <?php } else { ?>
                        <div class="col-md-12">
                    <?php } ?>
                        <div class="copyright">
                            Copyright &copy; 2023, <a href="<?php echo $baseurl; ?>" class="link">wonderkids.club</a>, all rights
                            reseved.
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </footer>
    </div>

    <div id="pdfDownloadModal" class="modal lg-rt-modal fade" data-bs-keyboard="false" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="pdfDownloadLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body popup-text">
                    <div class="row login-wrapper p-3">
                        <div class="text-end">
                            <button type="button" class="close p-0" data-bs-dismiss="modal" aria-label="Close" title="Close"><svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M16.9739 15.1626L23.8989 22.0876V23.9126H22.0739L15.1489 16.9876L8.22393 23.9126H6.39893V22.0876L13.3239 15.1626L6.39893 8.2376V6.4126H8.22393L15.1489 13.3376L22.0739 6.4126H23.8989V8.2376L16.9739 15.1626Z" fill="black"/>
                                </svg>
                            </button>
                        </div>
                        <div class="col-lg-12 ps-lg-0">
                            <div class="loginform pb-4">
                                <div class="mb-3 ms-3">
                                    <h2 class="title">
                                        Download PDF 
                                    </h2>
                                </div>
                                <div class="form-signup p-0 mb-2" id="pdf-download-container"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="messageModal" class="modal lg-rt-modal fade" data-bs-keyboard="false" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body popup-text">
                    <div class="row login-wrapper p-3">
                        <div class="text-end">
                            <button type="button" class="close p-0" data-bs-dismiss="modal" aria-label="Close" title="Close"><svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M16.9739 15.1626L23.8989 22.0876V23.9126H22.0739L15.1489 16.9876L8.22393 23.9126H6.39893V22.0876L13.3239 15.1626L6.39893 8.2376V6.4126H8.22393L15.1489 13.3376L22.0739 6.4126H23.8989V8.2376L16.9739 15.1626Z" fill="black"/>
                                </svg>
                            </button>
                        </div>
                        <div class="col-lg-12 ps-lg-0">
                            <div class="loginform pb-4">
                                <div class="mb-3 ms-3">
                                    <h2 class="title">
                                        Messages
                                    </h2>
                                </div>
                                <div class="form-signup p-0 mb-2">
                                    <div class="message-types" id="message-types"></div>
                                    <div class="messages" id="messages"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="contactModal" class="modal lg-rt-modal fade" data-bs-keyboard="false" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body popup-text">
                    <div class="row login-wrapper p-3">
                        <div class="text-end">
                            <button type="button" class="close p-0" data-bs-dismiss="modal" aria-label="Close" title="Close"><svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M16.9739 15.1626L23.8989 22.0876V23.9126H22.0739L15.1489 16.9876L8.22393 23.9126H6.39893V22.0876L13.3239 15.1626L6.39893 8.2376V6.4126H8.22393L15.1489 13.3376L22.0739 6.4126H23.8989V8.2376L16.9739 15.1626Z" fill="black"/>
                                </svg>
                            </button>
                        </div>
                        <div class="col-lg-12 ps-lg-0">
                            <div class="loginform pb-4">
                                <div class="mb-3 ms-3">
                                    <h2 class="title">
                                        Contact Us
                                    </h2>
                                </div>
                                <div class="form-signup p-0 mb-2">
                                    <form action="" method="post" class="w-100 p-2">
                                        <div class="input-group mb-2" style="height: 30px">
                                            <select name="subject-select" id="form-select" class="w-100">
                                                <option value="" selected disabled>Select Subject</option>
                                                <option value="Feedback/Suggestions">Feedback/Suggestions</option>
                                                <option value="Complaints">Complaints</option>
                                                <option value="Collaborations">Collaborations</option>
                                                <option value="Payment & Refunds">Payment & Refunds</option>
                                                <option value="Others">Others</option>
                                            </select>
                                        </div>
                                        <div class="input-group mb-2">
                                            <textarea name="query-content" id="" class="w-100" cols="30" rows="10" placeholder="Please type your query here"></textarea>
                                        </div>
                                        <div class="m-2 w-100">
                                            <input type="submit" class="btn btn-primary custom-btn" name="contact" value="Submit">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

  <div id="loginModal" class="modal lg-rt-modal fade" data-bs-keyboard="false" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body popup-text">
            <div class="row login-wrapper">
                        <div class="col-lg-6 p-0 tab-none">
                            <div class="image-container">
                                <img class="img-fit" src="<?php echo $baseurl; ?>assets/images/login.jpg" width="320" height="450" alt="">
                            </div>
                        </div>                        
                        <div class="col-lg-6 ps-lg-0">
                            <div class="p-3">
                            <div class="text-end">
                                <button type="button" class="close p-0" data-bs-dismiss="modal" aria-label="Close" title="Close"><svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16.9739 15.1626L23.8989 22.0876V23.9126H22.0739L15.1489 16.9876L8.22393 23.9126H6.39893V22.0876L13.3239 15.1626L6.39893 8.2376V6.4126H8.22393L15.1489 13.3376L22.0739 6.4126H23.8989V8.2376L16.9739 15.1626Z" fill="black"/>
</svg>
</button>
                            </div>
                            <div class="loginform pb-4">
                            <div class="mb-3">
                                <h2 class="title">Login</h2>
                            </div>
                                                    <div class="form-signup p-0 mb-2">
                                                    <?php if(isset($errMsg)){ echo "".$errMsg.""; } ?>
                        <form action="" method="post">
                            <div class="mb-2">
                                <input type="text" name="email" class="form-control emailtxt" placeholder="Email / Phone Number" required>
                            </div>
                            <div class="mb-2">
                                <div class="input-group input-append">  
                                    <input type="password" name="tp_pass" id="tp_pass" class="form-control tp_pass noSpacesField" autocomplete="off" placeholder="Login Password" required>
                                    <div class="input-group-append">
                                      <button class="btn btn-link eye-off" id="viewButton" type="button"><img src="<?php echo $baseurl; ?>assets/images/eye-off.svg" width="22"></button>
                                    </div>                                   
                                  </div>                                 
                            </div>
                        <div class="mb-2 text-start btn-wrapper mt-3">
                        <input type="submit" name="login" class="btn btn-animated btn-lg" value="Login">
                    </div>
                    </form>
                    
                        </div> 
                        <div class="link text-center">
                            New to Wonderkids? <a class="registerModal" href="#register" data-bs-toggle="modal" data-bs-target="#registerModal">Create account</a>
                        </div>  </div> 
                         
                        </div>             
                        </div>
                    </div></div>
            </div>
        </div>
    </div>
</div>
</div>

<div id="registerModal" class="modal lg-rt-modal fade" data-bs-keyboard="false" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="registerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body popup-text">
            <div class="row login-wrapper">
                        <div class="col-md-6 p-0 tab-none">
                            <div class="image-container">
                                <img class="img-fit" src="<?php echo $baseurl; ?>assets/images/registration.jpg" width="320" height="450" alt="">
                            </div>
                        </div>                        
                        <div class="col-lg-6 ps-lg-0">
                            <div class="p-3">
                            <div class="text-end">
                                <button type="button" class="close p-0" data-bs-dismiss="modal" aria-label="Close" title="Close"><svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16.9739 15.1626L23.8989 22.0876V23.9126H22.0739L15.1489 16.9876L8.22393 23.9126H6.39893V22.0876L13.3239 15.1626L6.39893 8.2376V6.4126H8.22393L15.1489 13.3376L22.0739 6.4126H23.8989V8.2376L16.9739 15.1626Z" fill="black"/>
</svg>
</button>
                            </div>
                            <div class="mb-3">
                                <h2 class="title">Register</h2>
                            </div>
                                                    <div class="form-signup p-0 mb-2">
                                                    <?php if(isset($errMsg2)){ echo $errMsg2; } ?>
                                                    <form action="" method="post" enctype="multipart/form-data">
                                                        <div class="mb-2 multi-btn userType">
                                                        <div class="check-btn">
                                        <input class="form-check-input" type="radio" name="utype" value="1" id="utype_1" checked>
                                        <div class="label-wrapper">
                                            <label for="utype_1"></label>
                                            <span class="notchecked">Student</span>
                                        </div>
                                    </div>
                                    <div class="check-btn">
                                    <input class="form-check-input" type="radio" name="utype" value="2" id="utype_2">
                                        <div class="label-wrapper">
                                            <label for="utype_2"></label>
                                            <span class="notchecked">Teacher</span>
                                        </div>
                                    </div>
                                                        </div>
                        <div class="mb-2">
                            <input type="text" name="fullname" class="form-control" placeholder="Fullname" value="<?php echo $_REQUEST['fullname']; ?>" required>
                        </div>
                        <div class="mb-2">
                            <input type="email" name="email" class="form-control emailtxt" placeholder="Email" value="<?php echo $_REQUEST['email']; ?>" required>
                        </div>
                        <div class="mb-2">
                            <input type="tel" name="mobile" class="form-control" placeholder="Mobile" value="<?php echo $_REQUEST['mobile']; ?>" required>
                        </div>
                        <div class="mb-2">
                            <div class="input-group input-append">  
                                <input type="password" name="password" id="password" class="form-control tp_pass noSpacesField" autocomplete="off" placeholder="Login Password" required>
                                <div class="input-group-append">
                                  <button class="btn btn-link form-control eye-off" id="viewButton" type="button"><img src="<?php echo $baseurl; ?>assets/images/eye-off.svg" width="22"></button>
                                </div>
                              </div>
                        </div>
                        <div class="mb-2">
                        <select name="clsName" id="clsName" class="form-select">
                                    <option value="">Please Select</option>
                                    <?php 
                                    $catsql = mysqli_query($conn, "SELECT id,name from subject_class WHERE type=2 and status=1 order by id asc");
                                    while($catrow = mysqli_fetch_array($catsql)) { ?>
                                        <option value="<?php echo $catrow['id']; ?>"><?php echo $catrow['name']; ?></option>
                                    <?php } ?>
                                    </select>    
                    </div>
                        <div class="mb-2">
                        <select name="school" id="school" class="form-select" required>
                                    <option value="">Please Select</option>
                                    <option value="others">Others</option>
                                    <?php 
                                    $catsql = mysqli_query($conn, "SELECT id,name,short_form from school_management WHERE status=1 order by name asc");
                                    while($catrow = mysqli_fetch_array($catsql)) { ?>
                                        <option value="<?php echo $catrow['id']; ?>"><?php echo $catrow['name']; ?><?php if(!empty($catrow['short_form'])) { echo ' ('.$catrow['short_form'].')'; } ?></option>
                                    <?php } ?>
                                    </select>
                        </div>
                        <div class="mb-2 others hide">
                                <input type="text" name="others" class="form-control" placeholder="School Name">
                            </div>
                        <div class="mb-2 text-center btn-wrapper mt-3">
                        <input type="submit" name="register" class="btn btn-animated btn-lg" value="Register">
                    </div>
                    </form>
                        </div> 
                        <div class="link text-center">
                        Already have an account? <a class="loginModal" href="#login" data-bs-toggle="modal" data-bs-target="#loginModal">Sign in</a>
                        </div>               
                        </div>
                    </div>
                    </div>
            </div>
        </div>
    </div>
</div>

<?php if($page !== "practice.php") {
    unset($_SESSION["prev_ques"]);
} ?>
<?php if(isset($_SESSION["id"])) { ?>
    <script>
        var messageTypeContainer = document.getElementById("message-types");
        var messagesContainer = document.getElementById("messages");
        var data = [];

        $.ajax({
            type: "post",
            url: "<?php echo $baseurl; ?>ajax/getMessagesAjax",
            data: {
                user_id: "<?php echo $_SESSION["id"]; ?>"
            },
            success: function(res) {
                data = JSON.parse(res);
                populateMessages(data);
            }
        });

        $.ajax({
            type: "post",
            url: "<?php echo $baseurl; ?>ajax/getMessageTypesAjax",
            data: {
                user_id: "<?php echo $_SESSION["id"]; ?>"
            },
            success: function(res) {
                var response = JSON.parse(res);

                var types = [
                                {str: "All", type: "All_Count"},
                                { str: "Feedback/Suggestions", type: "Feedback_Suggestions_Count" },
                                { str: "Complaints", type: "Complaints_Count" },
                                { str: "Collaborations", type: "Collaborations_Count" },
                                { str: "Payment & Refunds", type: "Payment_Refunds_Count" },
                                { str: "Report Questions", type: "Report_Question" },
                                { str: "Others", type: "Others_Count" }
                            ];

                types.forEach((mtype) => {

                    // console.log(response);

                    var button = document.createElement("button");
                    button.innerHTML = mtype.str + `<span>${(response[mtype.type]) ? response[mtype.type] : 0}</span>`;

                    if(mtype.str == "All") {
                        button.classList.add("clicked");
                    }

                    button.addEventListener("click", function (event) {

                        clearButtons();

                        button.classList.add("clicked");

                        if(mtype.str == "All") {
                            populateMessages(data);
                        }
                        else {
                            var filtered = data.filter((element) => element.subject == mtype.str);
                            populateMessages(filtered);
                        }
                    });

                    messageTypeContainer.appendChild(button);
                });
            }
        });

        function clearButtons() {
            var buttons = document.querySelectorAll(".message-types button");
            buttons.forEach(button => {
                button.classList.remove('clicked');
            });
        }

        function populateMessages(data) {
            console.log(data);
            messagesContainer.innerHTML = "";
            data.forEach((element) => {
                var messageContent = document.createElement("div");

                var subjectContainer = document.createElement("div");
                subjectContainer.innerHTML = "<span>Subject: </span>" + element.subject;

                var contentContainer =document.createElement("div");
                contentContainer.innerHTML = "<span>Msg: </span>" + element.query_content.substring(0, 50) + "...";

                var messageTextContent = document.createElement("div");
                messageTextContent.innerHTML = "<span>Reply: </span>" + element.reply;

                var timeStampContainer = document.createElement('div');

                var timestamp = new Date(element.updated_at);

                // Current time
                var currentTime = new Date();

                var timezoneOffset = 0; // UTC-5 (for example)

                // Calculate the time difference in milliseconds (adjusted for time zone)
                var timeDifference = Date.now() - timestamp.getTime() - (timezoneOffset * 60 * 1000);

                // Convert milliseconds to seconds, minutes, and days
                var secondsAgo = Math.floor(timeDifference / 1000);
                var minutesAgo = Math.floor(secondsAgo / 60);
                var hoursAgo = Math.floor(minutesAgo / 60);
                var daysAgo = Math.floor(hoursAgo / 24);

                var unit = "seconds";

                if (daysAgo > 0) {
                unit = "days";
                } else if (hoursAgo > 0) {
                unit = "hours";
                } else if (minutesAgo > 0) {
                unit = "minutes";
                }

                var timeAgo = daysAgo || hoursAgo || minutesAgo || secondsAgo;

                timeStampContainer.innerHTML = timeAgo + " " + unit + " ago";

                messageContent.className = "message-content";

                messageContent.appendChild(subjectContainer);
                messageContent.appendChild(contentContainer);
                messageContent.appendChild(messageTextContent);
                messageContent.appendChild(timeStampContainer);

                messagesContainer.appendChild(messageContent);
            });
        }
    </script>
<?php } ?>

<?php if($page == 'index.php') { ?>
    <div id="assignModal" class="modal lg-rt-modal fade" data-bs-keyboard="false" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body popup-text">
            <div class="row bg-white login-wrapper align-items-center">
                        <div class="col-md-6 p-0 tab-none">
                            <div class="image-container">
                                <img class="img-fit" src="<?php echo $baseurl; ?>assets/images/practice.jpg" width="320" height="320" alt="">
                            </div>
                        </div>                        
                        <div class="col-md-6 pt-3">
                            <div class="text-end pos-absolute">
                                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close" title="Close"><svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16.9739 15.1626L23.8989 22.0876V23.9126H22.0739L15.1489 16.9876L8.22393 23.9126H6.39893V22.0876L13.3239 15.1626L6.39893 8.2376V6.4126H8.22393L15.1489 13.3376L22.0739 6.4126H23.8989V8.2376L16.9739 15.1626Z" fill="black"/>
</svg>
</button>
                            </div>
                            <div class="mb-3">
                                <h2 class="title">Assign by Teacher</h2>
                            </div>
                                                    <div class="form-signup p-1 mb-2">
                                                    <?php if(isset($errMsg)){ echo "".$errMsg.""; } ?>
                        <form action="" method="post">
                            <div class="mb-2">
                            <select name="tchusr" id="tchusr" class="form-select">
                                    <option>Select your name</option>
                                    <option value="0">Not in list</option>
                                    <?php 
                                    $grp_qry = mysqli_query($conn, "SELECT id from grpwise WHERE status=1 and link='".$prts."' order by name asc");
                                    $grp_rslt = mysqli_fetch_array($grp_qry);
                                        
                                    $catsql = mysqli_query($conn, "SELECT id,name from tch_grp_usr_list WHERE status=0 and grp_id='".$grp_rslt['id']."' and email = '' order by name asc");
                                    while($catrow = mysqli_fetch_array($catsql)) { ?>
                                        <option value="<?php echo $catrow['id']; ?>"><?php echo $catrow['name']; ?></option>
                                    <?php } ?>
                                    </select>
                                    </div>
                                    <div class="mb-2">
                                <div class="input-group input-append"> 
                                    <input type="hidden" name="subTopid" id="subtopic" value=""> 
                                    <input type="password" name="tp_pass" id="tp_pass" class="form-control tp_pass noSpacesField" autocomplete="off" placeholder="Enter given password" required>
                                    <div class="input-group-append">
                                      <button class="btn btn-link eye-off" id="viewButton" type="button"><img src="<?php echo $baseurl; ?>assets/images/eye-off.svg" width="22"></button>
                                    </div>                                   
                                  </div>                                 
                            </div>
                        <div class="mb-2 text-center btn-wrapper">
                        <input type="submit" name="assigngrp" class="btn custom-btn btn-w-full" value="Submit">
                    </div>
                    </form>
                        </div>               
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php } ?>
<?php if($page == 'practice.php') { ?>
    <div id="reportModal" class="modal lg-rt-modal fade" data-bs-keyboard="false" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="reportModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body popup-text">
            <div class="row bg-white login-wrapper align-items-center">                    
                        <div class="col-md-12 pt-3">
                            <div class="text-end pos-absolute">
                                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close" title="Close"><svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16.9739 15.1626L23.8989 22.0876V23.9126H22.0739L15.1489 16.9876L8.22393 23.9126H6.39893V22.0876L13.3239 15.1626L6.39893 8.2376V6.4126H8.22393L15.1489 13.3376L22.0739 6.4126H23.8989V8.2376L16.9739 15.1626Z" fill="black"/>
</svg>
</button>
                            </div>
                            <div class="mb-1">
                                <h2 class="title">Report Question</h2>
                            </div>
                                                    <div class="form-signup p-1 mb-2">
                                                    <?php if(isset($errMsg)){ echo "".$errMsg.""; } ?>
                        <form action="" method="post" class="reportForm">
                            <div class="mb-md-3 mb-2">
                                <div class="input-group input-append"> 
                                    <input type="hidden" name="subTopid" id="subtopic" value=""> 
                                    <textarea rows="5" name="report" id="report" class="form-control" required></textarea>                                 
                                  </div>                                 
                            </div>
                        <div class="mb-2 text-center btn-wrapper">
                        <input type="submit" name="reportBtn" class="btn btn-pink btn-animated btn-lg mw-200" value="Submit">
                    </div>
                    </form>
                        </div>               
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php } ?>
</div>
    <script src="<?php echo $baseurl; ?>assets/js/popper.min.js"></script>
    <script src="<?php echo $baseurl; ?>assets/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>

    <script src="<?php echo $baseurl; ?>assets/js/custom.js"></script>

    <script>
//         function addToast(title, content, canClose, canAutoHide) {
//     const toastDiv = document.createElement('div');
//     toastDiv.classList.add('toast', 'hide');
//     toastDiv.setAttribute('role', 'alert');
//     toastDiv.setAttribute('aria-live', 'assertive');
//     toastDiv.setAttribute('aria-atomic', 'true');
//     toastDiv.setAttribute('id', 'myToast');
//     toastDiv.setAttribute('data-bs-animation', 'true');
//     !canAutoHide && toastDiv.setAttribute('data-bs-autohide', 'false'); 

//     const toastHeaderDiv = document.createElement('div');
//     toastHeaderDiv.classList.add('toast-header');

//     // const img = document.createElement('img');
//     // img.src = 'path_to_image'; // Replace 'path_to_image' with the image URL
//     // img.classList.add('rounded', 'me-2');
//     // img.alt = 'Image Alt Text';

//     const strongTitle = document.createElement('strong');
//     strongTitle.classList.add('me-auto');
//     strongTitle.setAttribute('id', 'toast-title');
//     strongTitle.textContent = title;

//     const smallTime = document.createElement('small');
//     smallTime.classList.add('text-muted');
//     smallTime.textContent = 'just now';

//     const closeButton = document.createElement('button');
//     closeButton.setAttribute('type', 'button');
//     closeButton.classList.add('btn-close');
//     closeButton.setAttribute('data-bs-dismiss', 'toast');
//     closeButton.setAttribute('aria-label', 'Close');

//     const toastBodyDiv = document.createElement('div');
//     toastBodyDiv.classList.add('toast-body');
//     toastBodyDiv.setAttribute('id', 'toast-body');
//     toastBodyDiv.textContent = content;

//     // Append elements to create the structure
//     // toastHeaderDiv.appendChild(img);
//     toastHeaderDiv.appendChild(strongTitle);
//     toastHeaderDiv.appendChild(smallTime);
//     canClose && toastHeaderDiv.appendChild(closeButton);

//     toastDiv.appendChild(toastHeaderDiv);
//     toastDiv.appendChild(toastBodyDiv);

//     return toastDiv;
// }

function addToast(toastObj) {
    const toastDiv = document.createElement('div');
    toastDiv.classList.add('toast', 'hide');
    toastDiv.setAttribute('role', 'alert');
    toastDiv.setAttribute('aria-live', 'assertive');
    toastDiv.setAttribute('aria-atomic', 'true');
    toastDiv.setAttribute('id', 'myToast');
    toastDiv.setAttribute('data-bs-animation', 'true');

    const toastHeaderDiv = document.createElement('div');
    toastHeaderDiv.classList.add('toast-header', 'd-flex', 'align-items-center', 'justify-content-center');

    const img = document.createElement('img');
    img.src = `<?php echo $baseurl; ?>assets/notification_icons/${toastObj.imgBanner}`; // Replace 'path_to_image' with the image URL
    img.classList.add('rounded', 'me-2');
    img.setAttribute('width', '170px');
    img.setAttribute('height', '170px');
    img.alt = 'Notification Img';

    const strongTitle = document.createElement('strong');
    strongTitle.classList.add('me-auto', 'text-center', 'w-100');
    strongTitle.setAttribute('id', 'toast-title');
    strongTitle.textContent = toastObj.title;

    const toastBodyDiv = document.createElement('div');
    toastBodyDiv.classList.add('toast-body', 'd-flex', 'flex-column', 'justify-content-center', 'align-items-center');
    toastBodyDiv.setAttribute('id', 'toast-body');

    const toastBodySubDiv =document.createElement('div');
    toastBodySubDiv.classList.add('d-flex', 'justify-content-evenly', 'align-items-center', 'mb-2');

    var textNode = document.createElement('div');
    textNode.textContent = toastObj.content;
    textNode.classList.add('fun-text', 'bouncing-text');

    var streakDiv;
    if(toastObj?.streak) {
        streakDiv = document.createElement('div');
        streakDiv.innerHTML = '<img src="<?php echo $baseurl; ?>assets/notification_icons/streak.svg" width="10px" height="12px" alt="streak">' + toastObj.streak;
    }
    // Append elements to create the structure
    toastHeaderDiv.appendChild(strongTitle);

    toastBodySubDiv.appendChild(img);
    toastBodySubDiv.appendChild(textNode);

    toastBodyDiv.appendChild(toastBodySubDiv);
    toastObj?.streak && toastBodyDiv.appendChild(streakDiv);

    toastDiv.appendChild(toastHeaderDiv);
    toastDiv.appendChild(toastBodyDiv);

    return toastDiv;
}

function showToast(toastObj) {

    var myToast = addToast(toastObj);

    document.getElementById('toast-container').appendChild(myToast);

    var toast = new bootstrap.Toast(myToast);
    // $('#toast').toggleClass('hidden-toast visible-toast');
    toast.show();
}

function showTimerToast(title, targetTimestamp, canClose, canAutoHide) {

    var now = Math.floor(Date.now() / 1000);
    var timeRemaining = targetTimestamp - now;

    var hours = Math.floor(timeRemaining / 3600);
    var minutes = Math.floor((timeRemaining % 3600) / 60);
    var seconds = timeRemaining % 60;


    var container = $('#container');
    var innerDiv = container.find('div');

    var timerContent = `${(hours + "").padStart(2, '0')} : ${(minutes + "").padStart(2, '0')} : ${(seconds + "").padStart(2, '0')}`;

    var myToast = document.querySelectorAll('#timer-toast-container .toast');
    var toast;

    if(myToast.length == 0){
        myToast = addToast(title, timerContent, false, false);
        document.getElementById('timer-toast-container').innerHTML = '';
        document.getElementById('timer-toast-container').appendChild(myToast);

        toast = new bootstrap.Toast(myToast);


    } else {
        var toastBodyDec =document.querySelectorAll('#timer-toast-container .toast .toast-body');
        toastBodyDec[0].textContent = timerContent;

        toast = new bootstrap.Toast(myToast[0]);

    }


    if(timeRemaining > 0) {
        toast.show();
        // $('#toast').toggleClass('hidden-toast visible-toast');
        setTimeout(() => showTimerToast(title, targetTimestamp, canClose, canAutoHide), 1000);
    } else {
        // toast.remove();
        $.ajax({
            type: "GET",
            url: "<?php echo $baseurl; ?>ajax/disablePowerUp?power_up=double",
            success: function(res) {
                toast.hide();
                myToast[0].remove();
            }
        });
    }
}
</script>
<?php if(isset($_SESSION['id'])) { 
    if(isset($_SESSION['power-up']) && isset($_SESSION['destination-timer']) && $_SESSION['power-up'] == 'double') {    
        ?> 
            <script>
                var targetTimestamp = <?php echo $_SESSION['destination-timer']; ?>;
                showTimerToast('Timer', targetTimestamp, false, false);
            </script>
        <?php
    } 
} ?>

<?php if($page == 'category.php' || $page == 'dashboard.php') { ?>
<script>$(document).ready(function(){$(".blk-widget-inner a").click(function(){var t=$(this).data("grp");$.ajax({url:"<?php echo $baseurl;?>actajax",type:"POST",data:{assign_grp:t},success:function(t){}})})}),$(document).ready(function(){$(".acpt-grp").on("click",function(t){t.preventDefault();t=$(this).data("id");$("#subtopic").val(t)})}),$(document).ready(function(){$(".blk-widget-inner a").click(function(){$(this).data("id"),$(this).next(".tag").hide()})}),$(document).ready(function(){$(".fastest-topic").click(function(){var t=$(this).data("topic");$.ajax({url:"<?php echo $baseurl;?>actajax",type:"POST",data:{asgn_topic:t},success:function(t){location.reload()}})})});</script>
<script>

    function fetch_pdf(){

        var subtopic_id = event.target.getAttribute("data-id");

        $.ajax({
            type: "get",
            url: `<?php echo $baseurl; ?>ajax/fetch_pdfs?subtopic_id=${subtopic_id}`,
            success: function(res){
                var response = JSON.parse(res);
                var pdf_container = document.getElementById("pdf-download-container");
                pdf_container.innerHTML = "";
                response.forEach((worksheet, index) => {
                    var file_path = "<?php echo $baseurl; ?>uploads/practice/" + worksheet.pdf_class + "/" + worksheet.filename;

                    var rowDiv = document.createElement("div");
                    rowDiv.className = "p-3 d-flex align-items-center justify-content-between w-100 border-bottom";
                    
                    var worksheet_title = document.createElement("h5");
                    worksheet_title.textContent = `Worksheet ${index + 1}`;

                    var downloadButton = document.createElement("button");
                    downloadButton.className = "btn btn-primary custom-btn";
                    downloadButton.textContent = "Download"

                    downloadButton.addEventListener("click", ()=>{

                        // Create an anchor element
                        const anchor = document.createElement('a');
                        document.body.appendChild(anchor);
                        // Set the anchor's href attribute to the PDF file URL
                        anchor.href = file_path;

                        // Set the anchor's download attribute to specify the file name
                        anchor.download = worksheet.filename;

                        // Trigger a click event on the anchor to start the download
                        anchor.click();

                        // Remove the anchor element from the DOM
                        document.body.removeChild(anchor);
                    });

                    rowDiv.appendChild(worksheet_title);
                    rowDiv.appendChild(downloadButton);
                    pdf_container.appendChild(rowDiv);
                    
                });
            }
        });
    }

    function checkFileExistence(filePath) {
        fetch(filePath)
            .then(response => {
                if (response.status === 200) {
                    return true;
                } else {
                    return false;
                }
            })
            .catch(error => {
                console.error('Error checking file existence:', error);
            });
    }
</script>
<?php } ?>
<?php if($page == 'quiz.php' || $page == 'fastest.php') { ?>
<script>$(document).ready(function(){
<?php if($page == 'quiz.php') { ?>    
var o=new Date("<?php echo $createdDateTime; ?>").getTime();
<?php } else { ?>
var o=new Date("<?php echo $createdDateTime; ?>").getTime(); // Initialize 'o' with the current time
<?php } ?>
function e() {
    var currentTime = new Date();
    var elapsedTime = currentTime.getTime() - o;
    var hours = Math.floor(elapsedTime / 3600000);
    var minutes = Math.floor((elapsedTime % 3600000) / 60000);
    var seconds = Math.floor((elapsedTime % 60000) / 1000);

    // Format hours, minutes, and seconds with leading zeros
    var formattedTime = 
        (hours < 10 ? "0" + hours : hours) + ":" +
        (minutes < 10 ? "0" + minutes : minutes) + ":" +
        (seconds < 10 ? "0" + seconds : seconds);

    $("#timer").text(formattedTime);
}

e(); // Call the function once to initialize the timer
setInterval(e, 1000); // Call the function every 1000 milliseconds (1 second) to update the timer

});</script>
<?php } ?>


    <?php if($page == 'index.php') { ?>
<script>
var swiperBanner = new Swiper('.hero-wrapper', {
            slidesPerView: 1,
            spaceBetween: 0,
            freeMode: false,
            speed: 3000,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            loop: true,
            autoplay: {
                delay: 5000,
            },
            navigation: {
            nextEl: '.swiper-next',
            prevEl: '.swiper-prev',
        }
        });
        
$(document).on('click','.teacherRegister',function(){
    $('#utype_2').prop('checked', true);
    $('#clsName').hide();
});

$(document).on('click','.studentRegister',function(){
    $('#utype_1').prop('checked', true);
    $('#clsName').show();
});

$(document).ready(function() {
  $('.emailtxt').on('input', function() {
    $(this).val($(this).val().toLowerCase());
  });
});

$(document).on('click','.eye-off', function () {
    $(this).children('img').attr('src', 'assets/images/eye.svg');
    $(this).addClass('eye-on');
    $(".tp_pass").attr('type','text'); 
});
$(document).on('click','.eye-on', function () {
    $(this).children('img').attr('src', 'assets/images/eye-off.svg');
    $(this).removeClass('eye-on');
    $(".tp_pass").attr('type','password');  
});


$(document).on('click','.loginModal',function(){
    $("#registerModal").modal("hide");
});

$(document).on('click','.registerModal',function(){
    $("#loginModal").modal("hide");
});

$(document).on('click','.teacherRegister',function(){
    $("#registerModal").modal("hide");
});



$(document).on('click','.dropdown-item',function(){
    if ($("button.form-select").attr("data-dselect-text") === "Others") {
      $('.others').removeClass('hide');
    } else {
      $('.others').addClass('hide');
    }
  });


var select_box_element = document.querySelector('#school');

    dselect(select_box_element, {
        search: true
    });

    var select_box_element = document.querySelector('#tchusr');

dselect(select_box_element, {
    search: true
});  

/*$(document).ready(function(){
  $("#school").select2();
});*/

$(document).ready(function() {
    $('input[type=radio][name=utype]').change(function() {
        if (this.value == '1') {
            $('#clsName').show();
        }
        else if (this.value == '2') {
            $('#clsName').hide();
        }
    });
});

// Reload the page when the modal is closed
$('#assignModal').on('hidden.bs.modal', function () {
    window.location.href = '<?php echo $baseurl; ?>';
    });
</script>
<?php } ?>
<?php if($page == 'leaderboard.php') { ?>
<style>
    .tooltip {
        display: none;
        position: absolute;
        background-color: #fff;
        border: 1px solid #ccc;
        /*padding: 5px;*/
        z-index: 1000; /* Adjust the z-index as needed */
        box-shadow: rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px;
        border-radius: 1.5rem;
    }
</style>
<script>
$(document).on('click','.leaderboard-wrapper a[data-overall]',function(){
    $(this).parents('.leaderboard-wrapper').find('a').removeClass('active');
    $(this).addClass('active');
    $(this).parents('.leaderboard-wrapper').children('.schoolwise').hide();
    $(this).parents('.leaderboard-wrapper').children('.overallwise').show();
});

$(document).on('click','.leaderboard-wrapper a[data-school]',function(){
    $(this).parents('.leaderboard-wrapper').find('a').removeClass('active');
    $(this).addClass('active');
    $(this).parents('.leaderboard-wrapper').children('.schoolwise').show();
    $(this).parents('.leaderboard-wrapper').children('.overallwise').hide();
});

// Get all list items with data-id attributes
const listItems = document.querySelectorAll('li[data-id]');

// Get the tooltip and iframe elements
const tooltip = document.querySelector('.tooltip');
const iframeContainer = document.querySelector('.iframe-container');
const iframe = document.querySelector('.iframe-container iframe');

// Detect if the user is using a touch device
function isMobileDevice() {
  return window.matchMedia("(max-width: 641px)").matches;
}

// Attach the appropriate event listener based on the device
listItems.forEach((li) => {
    let timer;
        // On touch devices, use click
        if(isMobileDevice()){
            li.addEventListener('click', (event) => {
                handleItemClick(li, event);
            });
        }
        else {
            li.addEventListener('mouseenter', (event) => {
                handleItemClick(li, event);

                tooltip.addEventListener('mouseenter', (event) => {
                handleItemClick(li, event);
                });

                tooltip.addEventListener('mouseleave', (event) => {
                    if (!tooltip.contains(event.target)) {
                            hideTooltip();
                    }
                });
            });

            

            li.addEventListener('mouseleave', (event) => {
                if (!tooltip.contains(event.target)) {
                    hideTooltip();
                }
            })
        }
});

document.addEventListener('click', (event) => {
            if (!tooltip.contains(event.target)) {
                hideTooltip();
            }
        });

// Function to handle both touch and mouse events
function handleItemClick(li, event) {
    // Get the data-id attribute value
    const dataId = li.getAttribute('data-id');

    // Update the iframe source based on data-id
    iframe.src = `profileTooltip.php?student_id=${dataId}`;
    iframe.width = "350";
    iframe.height = "207";
    iframe.style.padding = "0.25rem";

    // Calculate the tooltip position based on the mouse click or hover
    const liRect = li.getBoundingClientRect();
    tooltip.style.marginLeft = '40px'; // Adjust the offset as needed
    tooltip.style.top = (liRect.top + window.scrollY - 10) + 'px'; // Adjust the offset as needed

    // Show the tooltip and iframe
    tooltip.style.display = 'block';
    tooltip.style.opacity = 1;
    iframeContainer.style.display = 'block';

    // Prevent the click event from bubbling (optional)
    event.stopPropagation();
}

// Function to hide the tooltip and iframe
function hideTooltip() {
    iframe.src = '';
    tooltip.style.display = 'none';
    iframeContainer.style.display = 'none';
}
</script>    
<?php } ?>

<script>

<?php if($page == 'practice.php') { ?>
    var currentDate = new Date();

// Get the current date components
var year = currentDate.getFullYear();
var month = ('0' + (currentDate.getMonth() + 1)).slice(-2);
var day = ('0' + currentDate.getDate()).slice(-2);

// Get the current time components
var hours = ('0' + currentDate.getHours()).slice(-2);
var minutes = ('0' + currentDate.getMinutes()).slice(-2);
var seconds = ('0' + currentDate.getSeconds()).slice(-2);

// Create the formatted datetime string
var formattedDatetime = year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
  
$(document).on("click",".reportques",function(){
    $('#subtopic').val($(this).data('id'));
});
/*$(document).on("click",".reportques",function(){var a=$(this).data("id");$.ajax({url:'<?php echo $baseurl;?>actajax',method:'POST',data:{'reportQues':a,'datetime':formattedDatetime},success:function(response){$('.submitReport').text('Thanks');},
      error: function(xhr, status, error) {
        // Handle any errors that occur during the AJAX request
        console.log(error);
      }})});*/



    $(window).on('load', function() {
        $('#limitModal').modal('show');
    });

    function checkSelection() {
    var radioButtons = document.querySelectorAll('input[type="radio"][name="opt"]');
    var submitButton = document.getElementById("submitButton");

    for (var i = 0; i < radioButtons.length; i++) {
        if (radioButtons[i].checked) {
            submitButton.removeAttribute("disabled");
            return;
        }
    }

    submitButton.setAttribute("disabled", "true");
}

    function submitForm() {
            $.ajax({
                method: "POST",
                url: "<?php echo $baseurl;?>practice_rslt",
                data: $('#myForm').serialize(),
                success: function(response) {
                    $('#result').html(response);
                    resizeTextInContainers();
                    
                                $.ajax({
                method: "POST",
                url: "<?php echo $baseurl;?>performance_meter",
                data: $('#myForm').serialize(),
                success: function(response) {
                    $('#performance').html(response);
                    resizeTextInContainers();
                }
            });
                }
            });


        }

        function showNotification(text) {
        alert(text);
    }

    function setShortlist(event) {
        event.preventDefault();
        var clicker = event.currentTarget;
        var quesId = clicker.getAttribute("data-id");

        $.ajax({
            type: "post",
            url: "<?php echo $baseurl; ?>ajax/setShortList",
            data: {
                question_id: quesId,
                user_id: <?php echo json_encode($_SESSION["id"]); ?>
            },
            success: function(res) {
                clicker.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
  <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
</svg><span class="note">Shortlisted This Question</span>`;
            }
        });
    };

    function setShortlistMobile(event) {
        event.preventDefault();
        var clicker = event.currentTarget;
        var quesId = clicker.getAttribute("data-id");

        $.ajax({
            type: "post",
            url: "<?php echo $baseurl; ?>ajax/setShortList",
            data: {
                question_id: quesId,
                user_id: <?php echo json_encode($_SESSION["id"]); ?>
            },
            success: function(res) {
                clicker.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
  <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
</svg>`;
            }
        });
    };


    function removeShortlist(event) {
        event.preventDefault();
        var clicker = event.currentTarget;
        var quesId = clicker.getAttribute("data-id");

        $.ajax({
            type: "post",
            url: "<?php echo $baseurl; ?>ajax/removeShortList",
            data: {
                question_id: quesId,
                user_id: <?php echo json_encode($_SESSION["id"]); ?>
            },
            success: function(res) {
                clicker.innerHTML = ` <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star" viewBox="0 0 16 16">
  <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z"/>
</svg><span class="note">Shortlist This Question</span>`;
            }
        });
    }

    function removeShortlistMobile(event) {
        event.preventDefault();
        var clicker = event.currentTarget;
        var quesId = clicker.getAttribute("data-id");

        $.ajax({
            type: "post",
            url: "<?php echo $baseurl; ?>ajax/removeShortList",
            data: {
                question_id: quesId,
                user_id: <?php echo json_encode($_SESSION["id"]); ?>
            },
            success: function(res) {
                clicker.innerHTML = ` <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star" viewBox="0 0 16 16">
  <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z"/>
</svg>`;
            }
        });
    }


    function goToPrevQuestion(event) {
        event.preventDefault();
        $.ajax({
            type: "post",
            url: "<?php echo $baseurl; ?>ajax/visitPrevQuestion",
            data: {
                user_id: <?php echo $_SESSION['id']; ?>,
                class: <?php echo $clsrow['id']; ?>,
                subject: <?php echo $sbjrow['id']; ?>,
                topic: <?php echo $tpcrow['id']; ?>,
                subtopic: <?php echo $sbtpcrow['id']; ?>,
                question: <?php echo $querow['id']; ?>
            },
            success: function(res) {
                window.location.reload();
            }
        })
    }

    function goToNextQuestion(event) {
        event.preventDefault();
        $.ajax({
            type: "post",
            url: "<?php echo $baseurl; ?>ajax/visitNextQuestion",
            data: {
                user_id: <?php echo $_SESSION['id']; ?>,
                class: <?php echo $clsrow['id']; ?>,
                subject: <?php echo $sbjrow['id']; ?>,
                topic: <?php echo $tpcrow['id']; ?>,
                subtopic: <?php echo $sbtpcrow['id']; ?>,
                question: <?php echo $querow['id']; ?>,
            },
            success: function(res) {
                window.location.reload();
            }
        })
    }
<?php } ?>

<?php if($page == 'shortlist.php') {
    ?>

    function removeShortlist(event) {
        event.preventDefault();
        var clicker = event.currentTarget;
        var quesId = clicker.getAttribute("data-id");

        $.ajax({
            type: "post",
            url: "<?php echo $baseurl; ?>ajax/removeShortList",
            data: {
                question_id: quesId,
                user_id: <?php echo json_encode($_SESSION["id"]); ?>
            },
            success: function(res) {
                window.location.reload();
            }
        });
    }

     function checkSelection() {
    var radioButtons = document.querySelectorAll('input[type="radio"][name="opt"]');
    var submitButton = document.getElementById("submitButton");

    for (var i = 0; i < radioButtons.length; i++) {
        if (radioButtons[i].checked) {
            submitButton.removeAttribute("disabled");
            return;
        }
    }

    submitButton.setAttribute("disabled", "true");
}
           function submitForm() {
            $.ajax({
                method: "POST",
                url: "<?php echo $baseurl;?>practice_rslt_shortlist",
                data: $('#myForm').serialize(),
                success: function(response) {
                    $('#result').html(response);
                }
            });
        }
    <?php
} ?>

<?php if($page == 'paper.php') { ?>

    function runQuery() {
         var dataId = event.target.getAttribute("data-id");

         $.ajax({
            type: "get",
            url: `ajax/fetchQuizPaper?quiz_id=${dataId}`,
            success: function(res) {
                var response = JSON.parse(res);

                // Create an anchor element
                const anchor = document.createElement('a');
                document.body.appendChild(anchor);
                // Set the anchor's href attribute to the PDF file URL
                anchor.href = "<?php echo $baseurl; ?>uploads/offline_practice/" + response.question_papername;

                // Set the anchor's download attribute to specify the file name
                anchor.download = response.question_papername;

                // Trigger a click event on the anchor to start the download
                anchor.click();

                // Remove the anchor element from the DOM
                document.body.removeChild(anchor);
            }
         })
    }

    function runDQuery() {
        var dataId = event.target.getAttribute("data-id");

        $.ajax({
           type: "get",
           url: `ajax/fetchQuizPaper?quiz_id=${dataId}`,
           success: function(res) {
               var response = JSON.parse(res);

               // Create an anchor element
               const anchor = document.createElement('a');
               document.body.appendChild(anchor);
               // Set the anchor's href attribute to the PDF file URL
               anchor.href = "<?php echo $baseurl; ?>uploads/offline_practice/" + response.answer_papername;

               // Set the anchor's download attribute to specify the file name
               anchor.download = response.answer_papername;

               // Trigger a click event on the anchor to start the download
               anchor.click();

               // Remove the anchor element from the DOM
               document.body.removeChild(anchor);
           }
        })
   }
<?php } ?>

<?php 
 if($page == 'category.php' || $page == 'dashboard.php') { ?>
    window.jsPDF = window.jspdf.jsPDF;
    function runQuery() {
        // Get the data-id attribute value
        var dataId = event.target.getAttribute("data-id");
        // Create an AJAX request
        var xhr = new XMLHttpRequest();
        // Get the data-id attribute value
        var dataId = event.target.getAttribute("data-id");
        // Create an AJAX request
        var xhr = new XMLHttpRequest();

        // Set up the request
        xhr.open("POST", "../ajax/fetch_data.php?id="+ dataId, true);

        // Set the callback function to handle the response
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
            // Process the response here if needed
            generatePDFFromData(xhr.responseText);
        }
        };

        // Send the request
        xhr.send();
}

async function generatePDFFromData(resp) {
  var responseParent = JSON.parse(resp);
  var file_name = (responseParent.subtopic + responseParent.topic).replace(/ /g, "_");
  console.log(file_name);

  // Send data to the server to render HTML content
  fetch('../offline_ppr', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ data: responseParent.data })
  })
  .then(response => response.text())
  .then(async(html) => {

        var tempDiv = document.createElement('div');
        // Insert the received HTML into the temporary div

        tempDiv.innerHTML = html;

        console.log(tempDiv);
        
        let mywindow = window.open('', 'PRINT', 'height=650,width=900,top=100,left=100');

        mywindow.document.write(`<html><head><title>${file_name}</title>`);
        mywindow.document.write('</head><body >');
        mywindow.document.write(tempDiv.innerHTML);
        mywindow.document.write('</body></html>');

        // Add a delay before printing to allow time for the charts to render
        setTimeout(function () {
            mywindow.document.close(); // necessary for IE >= 10
            mywindow.focus(); // necessary for IE >= 10
            mywindow.print();
            mywindow.close();
        }, 5000); // Adjust the delay as needed

        // mywindow.document.title = file_name;

        return true;
    })
    .catch(error => console.error('promise_error: ', error));
}
<?php } ?>
</script>
<?php if($page='dashboard.php' || $page='leaderboard.php' || $page='practice.php') { ?>
    <script>
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})
    </script>
<?php } ?>
</body>
</html>