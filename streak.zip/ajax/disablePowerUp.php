<?php 
    include("../config/config.php");
    if($_GET['power_up']) {
        unset($_SESSION['power-up']);
        unset($_SESSION['destination-timer']);
        unset($_SESSION['power-timer']);

    }
?>